from setuptools import setup

setup(packages=["uwnet"])
